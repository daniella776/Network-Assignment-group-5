fprintf(fid, '[TITLE]\nSimple Looped Network\n\n');

fprintf(fid, '[JUNCTIONS]\n;ID  Elev(m)  Demand(L/s)\n');
fprintf(fid, 'J1  10  5\n');
fprintf(fid, 'J2  8   10\n');
fprintf(fid, 'J3  9   8\n');
fprintf(fid, 'J4  7   15\n\n');

fprintf(fid, '[RESERVOIRS]\n;ID  Head(m)\n');
fprintf(fid, 'R1  60\n\n');

fprintf(fid, '[PIPES]\n;ID  Node1  Node2  Length(m)  Diam(mm)  Roughness  MinorLoss  Status\n');
fprintf(fid, 'P1  R1  J1  500  300  120  0  Open\n');
fprintf(fid, 'P2  J1  J2  400  200  120  0  Open\n');
fprintf(fid, 'P3  J1  J3  400  200  120  0  Open\n');
fprintf(fid, 'P4  J2  J4  300  150  120  0  Open\n');
fprintf(fid, 'P5  J3  J4  300  150  120  0  Open\n\n');

fprintf(fid, '[OPTIONS]\nUnits LPS\nHeadloss H-W\n\n');
fprintf(fid, '[TIMES]\nDuration 0\n\n');

fprintf(fid, '[COORDINATES]\n;Node  X  Y\n');
fprintf(fid, 'R1  0    50\n');
fprintf(fid, 'J1  100  50\n');
fprintf(fid, 'J2  200  100\n');
fprintf(fid, 'J3  200  0\n');
fprintf(fid, 'J4  300  50\n\n');

fprintf(fid, '[END]\n');
fclose(fid);

d = epanet(inpFile);
d.solveCompleteHydraulics;

nodeIDs  = d.getNodeNameID;
linkIDs  = d.getLinkNameID;
pressure = d.getNodePressure;     
head     = d.getNodeHydraulicHead;
demand   = d.getNodeActualDemand; 
flow     = d.getLinkFlows;      
velocity = d.getLinkVelocity;     

fprintf('\n--- NODE RESULTS ---\n');
fprintf('%-6s %10s %12s %12s\n', 'Node', 'Head(m)', 'Pressure(m)', 'Demand(L/s)');
for k = 1:numel(nodeIDs)
    fprintf('%-6s %10.2f %12.2f %12.2f\n', nodeIDs{k}, head(k), pressure(k), demand(k));
end

fprintf('\n--- PIPE RESULTS ---\n');
fprintf('%-6s %12s %14s\n', 'Pipe', 'Flow(L/s)', 'Velocity(m/s)');
for k = 1:numel(linkIDs)
    fprintf('%-6s %12.2f %14.2f\n', linkIDs{k}, flow(k), velocity(k));
end

fprintf('\nFlow in P1 = %.2f L/s,  total demand = %.2f L/s\n', abs(flow(1)), 5+10+8+15);

d.plot;
title('Simple Looped Network');

figure;
bar(pressure(1:numel(nodeIDs)));
set(gca, 'XTickLabel', nodeIDs);
xlabel('Node'); ylabel('Pressure (m)');
title('Node Pressures'); grid on;

d.unload;
EOF